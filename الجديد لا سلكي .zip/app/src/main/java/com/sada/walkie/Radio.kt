package com.sada.walkie

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.media.Ringtone
import android.media.RingtoneManager
import android.os.Build
import android.os.PowerManager
import android.os.VibrationEffect
import android.os.Vibrator
import android.media.AudioAttributes
import android.media.AudioDeviceInfo
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.ToneGenerator
import android.media.MediaRecorder
import android.media.audiofx.AcousticEchoCanceler
import android.media.audiofx.AudioEffect
import android.media.audiofx.AutomaticGainControl
import android.media.audiofx.LoudnessEnhancer
import android.media.audiofx.NoiseSuppressor
import android.net.wifi.WifiManager
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.NetworkInterface
import java.net.SocketTimeoutException
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.ArrayDeque
import java.util.concurrent.ConcurrentHashMap
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.tanh
import kotlin.random.Random

private const val PORT = 40123
private const val RATE = 16000
private const val FRAME = 320            // 20ms من الصوت
private const val HEAD = 11              // [سحر][قناة][نوع][رقم المرسل x4][تسلسل x4]
private const val MAGIC = 0x5A
private const val T_HELLO = 0
private const val T_AUDIO = 1
private const val T_CALL = 3             // رنين: اتصال واردة (يُعاد كل ثانية حتى الرد)
private const val T_ACCEPT = 4           // رد
private const val T_DECLINE = 5          // رفض / مشغول
private const val T_END = 6              // إنهاء أو إلغاء
private const val CALL_RING_MS = 30_000L // مدة الرنين قبل «لم يردّ»
const val ACT_ANSWER = "com.sada.walkie.ANSWER"     // أزرار إشعار المكالمة (تعمل والشاشة مقفلة)
const val ACT_DECLINE = "com.sada.walkie.DECLINE"
const val ACT_HANGUP = "com.sada.walkie.HANGUP"
const val ACT_BOOT = "com.sada.walkie.BOOT"          // تشغيل تلقائي بعد إقلاع الهاتف
private const val PREBUF = 3             // عدد الإطارات قبل بدء التشغيل (60ms) لتخفيف التقطيع
private const val MAXQ = 16              // أقصى تأخير مسموح لكل مرسل (320ms)
private const val PRE_MAX = 8            // أقصى عمق لمخزن التأخير التكيفي (160ms)
private const val PEER_TTL = 6000L       // مدة بقاء الجهاز «حياً» بعد آخر حزمة منه
private const val MAX_RED_PEERS = 8      // فوق هذا العدد نوقف إرسال الإطار المكرر لتوفير الهواء
private const val MIC_GAIN = 1.4f
private val GAIN = floatArrayOf(1f, 1.8f, 2.8f, 4f)   // تكبير برمجي حسب مستوى القوة
private val ENH = intArrayOf(0, 300, 600, 900)        // تقوية إضافية من النظام (ملي بل)

/** حد ناعم يمنع التشويه الحاد عند رفع الصوت. المدخل والمخرج بين -1 و 1. */
private fun soft(x: Float): Float {
    val a = abs(x)
    if (a <= 0.6f) return x
    val y = 0.6f + 0.4f * tanh((a - 0.6f) / 0.4f)
    return if (x < 0f) -y else y
}

/**
 * جهاز لاسلكي عبر UDP Broadcast: بدون إنترنت وبدون إعداد.
 * - الإرسال من ميكروفون الهاتف نفسه.
 * - الاستقبال من سماعة الهاتف الخارجية (بصوت مرتفع) مع مخزن تأخير ودمج عدة متحدثين.
 */
class Radio private constructor(private val ctx: Context) {
    companion object {
        @Volatile private var inst: Radio? = null
        fun get(c: Context): Radio =
            inst ?: synchronized(this) { inst ?: Radio(c.applicationContext).also { inst = it } }
    }

    private class Src {
        val q = ArrayDeque<ShortArray>()
        var lastSeq = 0
        var started = false
        var playing = false
        var pre = PREBUF            // عمق المخزن الحالي (يكبر تلقائياً إذا تقطّعت الشبكة)
        var emptyAt = 0L
        var okRun = 0
        @Volatile var last = 0L

        @Synchronized
        fun take(): ShortArray? {
            if (!playing && q.size >= pre) playing = true
            if (!playing) return null
            val f = q.pollFirst()
            if (f == null) {
                playing = false; okRun = 0; emptyAt = System.currentTimeMillis()
            } else if (++okRun >= 500) {          // 10 ثوانٍ بلا انقطاع: صغّر المخزن تدريجياً
                okRun = 0
                if (pre > PREBUF) pre--
            }
            return f
        }
    }

    private val myId = Random.nextInt()
    private val audio = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager

    @Volatile var channel = 1
    @Volatile var listen = true
    @Volatile var lastRx = 0L
    @Volatile var phoneAudio = true      // سماعة وميكروفون الهاتف نفسه
    @Volatile var boost = 2              // 0..3
    @Volatile var running = false
        private set
    @Volatile var talking = false
        private set

    @Volatile private var gen = 0
    @Volatile private var targets: List<InetAddress> = emptyList()
    private var seq = 0
    private var sock: DatagramSocket? = null
    private var mcLock: WifiManager.MulticastLock? = null
    private val peersSeen = ConcurrentHashMap<Int, Pair<Int, Long>>()
    // عناوين الأجهزة التي سمعناها مباشرة: نرسل لها الصوت أحادياً (Unicast) لأنه أوثق من البث العام
    private val direct = ConcurrentHashMap<InetAddress, Long>()
    // عناوين أخبرنا بها جهاز آخر (لم نسمعها بعد): نرسل لها «مرحباً» فقط لنتعارف
    private val hints = ConcurrentHashMap<InetAddress, Long>()
    @Volatile private var myAddrs: Set<InetAddress> = emptySet()
    private val announced = ConcurrentHashMap<Int, Long>()

    // ---------- الهوية والمكالمات ----------
    private class Peer(val uid: String, var name: String, var ip: InetAddress, var pid: Int, var ch: Int, var last: Long)
    private val users = ConcurrentHashMap<String, Peer>()
    private var myUid = ByteArray(16)
    @Volatile var myUidHex = ""
        private set
    @Volatile var myName = ""
    @Volatile var callState = 0          // 0 فارغ، 1 اتصال صادر، 2 اتصال وارد، 3 متصل
        private set
    @Volatile var callUid = ""
        private set
    @Volatile var callReason = ""        // سبب الانتهاء: declined / ended / missed / timeout / lost / me
        private set
    @Volatile var callEvent = 0
        private set
    @Volatile private var callStarted = 0L
    @Volatile private var lastRingRx = 0L
    @Volatile var muted = false
        private set
    @Volatile var speaker = true
        private set
    @Volatile private var capGen = 0
    private val aecOk: Boolean = try { AcousticEchoCanceler.isAvailable() } catch (_: Throwable) { false }
    private var ringtone: Ringtone? = null
    private var ringTrack: AudioTrack? = null
    private var prox: PowerManager.WakeLock? = null
    private var ringWave: ShortArray? = null
    @Volatile private var kickFlag = false
    private var ringback: ToneGenerator? = null

    fun setIdentity(uid: ByteArray, name: String) {
        myUid = uid
        myUidHex = hex(uid, 0)
        myName = name
    }

    /** تحميل الهوية من التخزين (تُستخدم أيضاً من الخدمة إذا أُعيد تشغيلها بدون واجهة). */
    fun loadIdentity() {
        val p = ctx.getSharedPreferences("sada_net", Context.MODE_PRIVATE)
        val uid = p.getString("uid", null)
            ?: java.util.UUID.randomUUID().toString().also { p.edit().putString("uid", it).apply() }
        val u = java.util.UUID.fromString(uid)
        val ub = ByteBuffer.allocate(16).putLong(u.mostSignificantBits).putLong(u.leastSignificantBits).array()
        val nm = p.getString("name", null)
            ?: ("مستخدم " + (1000 + java.util.Random().nextInt(9000))).also { p.edit().putString("name", it).apply() }
        setIdentity(ub, nm)
    }

    private fun hex(b: ByteArray, off: Int): String {
        val sb = StringBuilder(32)
        for (i in 0 until 16) sb.append(String.format("%02x", b[off + i].toInt() and 0xFF))
        return sb.toString()
    }

    private fun unhex(s: String): ByteArray {
        val out = ByteArray(16)
        for (i in 0 until 16) out[i] = s.substring(i * 2, i * 2 + 2).toInt(16).toByte()
        return out
    }
    @Volatile var joinEvents = 0            // يزداد كلما انضم جهاز جديد (تقرأه الواجهة لإظهار إشعار)
        private set
    private var tg: ToneGenerator? = null
    private val srcs = ConcurrentHashMap<Int, Src>()
    private val headsetTypes = setOf(
        AudioDeviceInfo.TYPE_WIRED_HEADSET, AudioDeviceInfo.TYPE_WIRED_HEADPHONES,
        AudioDeviceInfo.TYPE_BLUETOOTH_A2DP, AudioDeviceInfo.TYPE_BLUETOOTH_SCO,
        AudioDeviceInfo.TYPE_USB_HEADSET
    )

    private fun alive(g: Int) = running && g == gen

    fun peers(): Int {
        val now = System.currentTimeMillis()
        return peersSeen.values.count { it.first == channel && now - it.second < 5000 }
    }

    @Synchronized
    fun start(): Boolean {
        if (running) return true
        return try {
            val wm = ctx.getSystemService(Context.WIFI_SERVICE) as WifiManager
            mcLock = wm.createMulticastLock("sada-mc").apply { setReferenceCounted(false); acquire() }
            sock = DatagramSocket(null).apply {
                reuseAddress = true
                broadcast = true
                soTimeout = 1000
                receiveBufferSize = 256 * 1024
                sendBufferSize = 256 * 1024
                bind(InetSocketAddress(PORT))
            }
            targets = findTargets()
            running = true
            val g = gen
            applyVolume()
            listOf(
                Thread({ receiveLoop(g) }, "sada-rx"),
                Thread({ playLoop(g) }, "sada-play"),
                Thread({ helloLoop(g) }, "sada-hello")
            ).forEach { it.isDaemon = true; it.start() }
            true
        } catch (e: Exception) {
            stop(); false
        }
    }

    @Synchronized
    fun stop() {
        running = false; talking = false
        gen++
        try { sock?.close() } catch (_: Exception) {}
        sock = null
        try { mcLock?.release() } catch (_: Exception) {}
        mcLock = null
        peersSeen.clear(); srcs.clear(); direct.clear(); hints.clear(); announced.clear()
        try { tg?.release() } catch (_: Exception) {}
        tg = null
        if (callState != 0) endCall("lost")
        ringStop(); ringbackStop(); cancelOngoing()
    }

    // ---------- المكالمات (رنين ثم رد أو رفض) ----------

    private fun sendSig(type: Int, target: String) {
        val p = users[target] ?: return
        val b = ByteArray(HEAD + 32)
        fill(b, type, 0)
        System.arraycopy(myUid, 0, b, HEAD, 16)
        System.arraycopy(unhex(target), 0, b, HEAD + 16, 16)
        sendTo(p.ip, b, b.size)
        sendTo(p.ip, b, b.size)      // مرتان لتقليل أثر ضياع الحزم
    }

    private fun onSignal(type: Int, buf: ByteArray, n: Int, now: Long) {
        if (n < HEAD + 32) return
        val caller = hex(buf, HEAD)
        if (hex(buf, HEAD + 16) != myUidHex) return
        when (type) {
            T_CALL -> when {
                callState == 0 -> {
                    callState = 2; callUid = caller; callReason = ""
                    callStarted = now; lastRingRx = now; callEvent++
                    ringStart(users[caller]?.name ?: "")
                }
                callUid == caller && callState == 2 -> lastRingRx = now
                callUid == caller && callState == 1 -> { callAccepted(); sendSig(T_ACCEPT, caller) }  // اتصلنا ببعض معاً
                callUid == caller && callState == 3 -> sendSig(T_ACCEPT, caller)                       // ضاع الرد: أعده
                else -> sendSig(T_DECLINE, caller)                                                     // مشغول
            }
            T_ACCEPT -> if (callState == 1 && callUid == caller) callAccepted()
            T_DECLINE -> if (callState == 1 && callUid == caller) endCall("declined")
            T_END -> if (callUid == caller && callState != 0) endCall(if (callState == 2) "missed" else "ended")
        }
    }

    private fun callTick(now: Long) {
        when (callState) {
            1 -> if (now - callStarted > CALL_RING_MS) { sendSig(T_END, callUid); endCall("timeout") }
                 else sendSig(T_CALL, callUid)
            2 -> if (now - lastRingRx > 5000) endCall("missed")
            3 -> { val p = users[callUid]; if (p == null || now - p.last > 15_000L) endCall("lost") }
        }
    }

    private fun callAccepted() {
        callState = 3; callReason = ""; callEvent++
        ringStop(); ringbackStop()
        startDuplex()
        postOngoing(users[callUid]?.name ?: "")
    }

    private fun endCall(reason: String) {
        val was = callState
        callState = 0; callReason = reason; callEvent++
        ringStop(); ringbackStop()
        if (was == 3) stopDuplex()
        cancelOngoing()
    }

    // ---------- صوت المكالمة: متبادل كامل (مثل الهاتف) مع إلغاء الصدى ----------

    private fun startDuplex() {
        muted = false
        speaker = false          // مثل المكالمة العادية: سماعة الأذن، وتنطفئ الشاشة بحساس القرب
        try {
            audio.mode = AudioManager.MODE_IN_COMMUNICATION
            audio.isSpeakerphoneOn = false
            val mx = audio.getStreamMaxVolume(AudioManager.STREAM_VOICE_CALL)
            audio.setStreamVolume(AudioManager.STREAM_VOICE_CALL, (mx * 0.8).toInt().coerceAtLeast(1), 0)
        } catch (_: Throwable) {}
        proxUpdate()
        if (running) startCapture()
    }

    private fun stopDuplex() {
        talking = false
        muted = false
        try {
            audio.isSpeakerphoneOn = false
            audio.mode = AudioManager.MODE_NORMAL
        } catch (_: Throwable) {}
        proxUpdate()
    }

    /** حساس القرب: تنطفئ الشاشة عند وضع الهاتف على الأذن أثناء المكالمة (سماعة الأذن فقط)، وتبقى مضاءة مع المكبر. */
    private fun proxUpdate() {
        try {
            if (callState == 3 && !speaker) {
                if (prox == null) {
                    val pm = ctx.getSystemService(Context.POWER_SERVICE) as PowerManager
                    if (pm.isWakeLockLevelSupported(PowerManager.PROXIMITY_SCREEN_OFF_WAKE_LOCK))
                        prox = pm.newWakeLock(PowerManager.PROXIMITY_SCREEN_OFF_WAKE_LOCK, "sada:prox")
                }
                prox?.let { if (!it.isHeld) it.acquire(4 * 60 * 60 * 1000L) }
            } else prox?.let { if (it.isHeld) it.release() }
        } catch (_: Throwable) {}
    }

    private fun startCapture() {
        talking = true
        val g = gen
        val id = ++capGen
        Thread({ captureLoop(g, id) }, "sada-mic").start()
    }

    fun setMuted(m: Boolean) {
        if (callState != 3) return
        muted = m
        if (m) talking = false else if (!talking && running) startCapture()
    }

    /** تنبيه: شبكة واي فاي جديدة أصبحت متاحة. */
    fun kick() { kickFlag = true }

    fun setSpeaker(s: Boolean) {
        speaker = s
        if (callState == 3) try { audio.isSpeakerphoneOn = s } catch (_: Throwable) {}
        proxUpdate()
    }

    fun call(uid: String): Boolean {
        if (!running || callState != 0 || uid.length != 32 || !users.containsKey(uid)) return false
        callUid = uid; callState = 1; callReason = ""
        callStarted = System.currentTimeMillis(); callEvent++
        sendSig(T_CALL, uid)
        ringbackStart()
        return true
    }

    fun answer() {
        if (callState != 2) return
        val u = callUid
        callAccepted()
        sendSig(T_ACCEPT, u)
    }

    fun decline() {
        if (callState != 2) return
        val u = callUid
        sendSig(T_DECLINE, u)
        endCall("me")
    }

    fun hangup() {
        if (callState == 0) return
        val u = callUid
        sendSig(T_END, u)
        endCall("me")
    }

    fun usersJson(): String {
        val now = System.currentTimeMillis()
        val a = org.json.JSONArray()
        for (p in users.values)
            a.put(org.json.JSONObject().put("uid", p.uid).put("name", p.name).put("online", now - p.last < 8000L))
        return a.toString()
    }

    fun callInfo(): String = org.json.JSONObject()
        .put("state", callState).put("uid", callUid)
        .put("name", users[callUid]?.name ?: "").put("reason", callReason).put("event", callEvent)
        .put("muted", muted).put("speaker", speaker).toString()

    private fun ringStart(name: String) {
        if (!classicRingStart()) {
            try {
                val r = RingtoneManager.getRingtone(ctx, RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE))
                if (Build.VERSION.SDK_INT >= 28) r.isLooping = true
                r.play()
                ringtone = r
            } catch (_: Throwable) {}
        }
        try {
            val v = ctx.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            v.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 700, 500), 0))
        } catch (_: Throwable) {}
        try {
            val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(
                NotificationChannel("sada_call", "المكالمات", NotificationManager.IMPORTANCE_HIGH).apply { setSound(null, null) }
            )
            val i = Intent(ctx, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                .putExtra("call", true)
            val pi = PendingIntent.getActivity(ctx, 7, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            val nt = Notification.Builder(ctx, "sada_call")
                .setSmallIcon(android.R.drawable.sym_call_incoming)
                .setContentTitle("مكالمة واردة")
                .setContentText(if (name.isEmpty()) "اضغط للرد" else name)
                .setCategory(Notification.CATEGORY_CALL)
                .setOngoing(true)
                .setContentIntent(pi)
                .setFullScreenIntent(pi, true)
                .addAction(android.R.drawable.sym_action_call, "رد", svcPi(11, ACT_ANSWER))
                .addAction(android.R.drawable.ic_menu_close_clear_cancel, "رفض", svcPi(12, ACT_DECLINE))
                .build()
            nm.notify(7001, nt)
        } catch (_: Throwable) {}
    }

    private fun svcPi(code: Int, action: String): PendingIntent =
        PendingIntent.getService(
            ctx, code, Intent(ctx, WalkieService::class.java).setAction(action),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

    /** إشعار «في مكالمة» مع زر إنهاء: يبقى ظاهراً والشاشة مقفلة. */
    private fun postOngoing(name: String) {
        try {
            val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(
                NotificationChannel("sada_call_on", "مكالمة جارية", NotificationManager.IMPORTANCE_LOW)
            )
            val open = PendingIntent.getActivity(
                ctx, 9, Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            val nt = Notification.Builder(ctx, "sada_call_on")
                .setSmallIcon(android.R.drawable.sym_call_outgoing)
                .setContentTitle("في مكالمة")
                .setContentText(name)
                .setCategory(Notification.CATEGORY_CALL)
                .setOngoing(true)
                .setContentIntent(open)
                .addAction(android.R.drawable.ic_menu_close_clear_cancel, "إنهاء", svcPi(13, ACT_HANGUP))
                .build()
            nm.notify(7002, nt)
        } catch (_: Throwable) {}
    }

    private fun cancelOngoing() {
        try { (ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).cancel(7002) } catch (_: Throwable) {}
    }

    /** رنة الهاتف الثابت القديم: جرس معدني يتدحرج «دررن... دررن» ثم صمت، وتتكرر. تُولَّد برمجياً بلا ملف صوتي. */
    private fun classicRingWave(): ShortArray {
        val sr = 22050
        val total = 3 * sr                      // دورة 3 ثوانٍ: رنة 0.4 + صمت 0.2 + رنة 0.4 + صمت 2.0
        val out = ShortArray(total)
        fun burst(startS: Double, durS: Double) {
            val a = (startS * sr).toInt()
            val b = minOf(((startS + durS) * sr).toInt(), total)
            for (i in a until b) {
                val t = (i - a).toDouble() / sr
                val ph = (t * 25.0) % 1.0                    // 25 ضربة مطرقة بالثانية
                val env = Math.exp(-ph * 9.0)                // كل ضربة تخفت سريعاً مثل الجرس
                val fade = minOf(1.0, minOf(t / 0.01, (durS - t) / 0.02)).coerceAtLeast(0.0)
                val w = Math.sin(2.0 * Math.PI * 1330.0 * t) * 0.55 +
                    Math.sin(2.0 * Math.PI * 1760.0 * t) * 0.30 +
                    Math.sin(2.0 * Math.PI * 2640.0 * t) * 0.15
                out[i] = (w * env * fade * 30000.0).toInt().toShort()
            }
        }
        burst(0.0, 0.4)
        burst(0.6, 0.4)
        return out
    }

    private fun classicRingStart(): Boolean = try {
        val w = ringWave ?: classicRingWave().also { ringWave = it }
        val t = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_NOTIFICATION_RINGTONE)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build()
            )
            .setAudioFormat(
                AudioFormat.Builder().setSampleRate(22050)
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build()
            )
            .setBufferSizeInBytes(w.size * 2)
            .setTransferMode(AudioTrack.MODE_STATIC)
            .build()
        t.write(w, 0, w.size)
        t.setLoopPoints(0, w.size, -1)
        t.play()
        ringTrack = t
        true
    } catch (_: Throwable) { false }

    private fun ringStop() {
        try { ringTrack?.stop() } catch (_: Throwable) {}
        try { ringTrack?.release() } catch (_: Throwable) {}
        ringTrack = null
        try { ringtone?.stop() } catch (_: Throwable) {}
        ringtone = null
        try { (ctx.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator).cancel() } catch (_: Throwable) {}
        try { (ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).cancel(7001) } catch (_: Throwable) {}
    }

    private fun ringbackStart() {
        try {
            val t = ToneGenerator(AudioManager.STREAM_MUSIC, 80)
            ringback = t
            t.startTone(ToneGenerator.TONE_SUP_RINGTONE)
        } catch (_: Throwable) {}
    }

    private fun ringbackStop() {
        try { ringback?.stopTone() } catch (_: Throwable) {}
        try { ringback?.release() } catch (_: Throwable) {}
        ringback = null
    }

    /** نغمة قبول: يُسمعها المضيف والمنضمون عند انضمام جهاز؛ والاتصال يُقبل دائماً (لا رفض ولا نافذة تأكيد). */
    private fun chime() {
        try {
            val t = tg ?: ToneGenerator(AudioManager.STREAM_MUSIC, 90).also { tg = it }
            t.startTone(ToneGenerator.TONE_PROP_ACK, 350)
        } catch (_: Throwable) {}
    }

    /** إعادة التشغيل بعد تغيّر الشبكة (انضمام لهوتسبوت مثلاً). */
    @Synchronized
    fun restart() {
        if (running) { stop(); start() }
    }

    // ---------- الصوت والمسارات ----------

    private fun headphonesConnected(): Boolean = try {
        audio.getDevices(AudioManager.GET_DEVICES_OUTPUTS).any { it.type in headsetTypes }
    } catch (_: Exception) { false }

    /** رفع مستوى وسائط النظام للأقصى عند التشغيل من سماعة الهاتف (إلا في مستوى «عادي»). */
    fun applyVolume() {
        try {
            val toSpeaker = phoneAudio || !headphonesConnected()
            if (boost >= 1 && toSpeaker) {
                audio.setStreamVolume(AudioManager.STREAM_MUSIC, audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC), 0)
            }
        } catch (_: Exception) {}
    }

    private fun route(track: AudioTrack, phone: Boolean) {
        try {
            val dev = if (phone) audio.getDevices(AudioManager.GET_DEVICES_OUTPUTS)
                .firstOrNull { it.type == AudioDeviceInfo.TYPE_BUILTIN_SPEAKER } else null
            track.setPreferredDevice(dev)
        } catch (_: Exception) {}
    }

    // ---------- الشبكة ----------

    private fun findTargets(): List<InetAddress> {
        val out = mutableListOf<InetAddress>()
        val mine = HashSet<InetAddress>()
        try {
            for (ni in NetworkInterface.getNetworkInterfaces()) {
                if (!ni.isUp || ni.isLoopback) continue
                for (ia in ni.interfaceAddresses) {
                    mine.add(ia.address)
                    ia.broadcast?.let { out.add(it) }
                }
            }
        } catch (_: Exception) {}
        myAddrs = mine
        if (out.isEmpty()) out.add(InetAddress.getByName("255.255.255.255"))
        return out
    }

    /** بث عام (يُستخدم للتعارف، وللصوت فقط حين لا نعرف أي جهاز بعد). */
    private fun send(buf: ByteArray, len: Int) {
        val s = sock ?: return
        for (t in targets) try { s.send(DatagramPacket(buf, len, t, PORT)) } catch (_: Exception) {}
    }

    private fun sendTo(ip: InetAddress, buf: ByteArray, len: Int) {
        val s = sock ?: return
        try { s.send(DatagramPacket(buf, len, ip, PORT)) } catch (_: Exception) {}
    }

    private fun liveDirect(): Int {
        val now = System.currentTimeMillis()
        return direct.values.count { now - it < PEER_TTL }
    }

    /** الصوت: أحادي لكل جهاز معروف (يُؤكَّد ويُعاد إرساله من طبقة الواي فاي)، وإلا بث عام. */
    private fun sendAudio(buf: ByteArray, len: Int) {
        val now = System.currentTimeMillis()
        if (callState == 3) {
            val p = users[callUid]
            if (p != null) { sendTo(p.ip, buf, len); return }
        }
        var sent = false
        for (e in direct.entries) {
            if (now - e.value < PEER_TTL) { sendTo(e.key, buf, len); sent = true }
        }
        if (!sent) send(buf, len)
    }

    private fun fill(b: ByteArray, type: Int, seqNo: Int) {
        b[0] = MAGIC.toByte(); b[1] = channel.toByte(); b[2] = type.toByte()
        ByteBuffer.wrap(b, 3, 8).putInt(myId).putInt(seqNo)
    }

    /** «مرحباً» = الترويسة + قائمة عناوين الأجهزة التي نسمعها (4 بايت لكل عنوان) ليتعارف الجميع بسرعة. */
    private fun buildHello(): ByteArray {
        val now = System.currentTimeMillis()
        val ips = direct.entries.filter { now - it.value < PEER_TTL }.map { it.key }.take(30)
        val nameB = myName.take(16).toByteArray(Charsets.UTF_8)
        val b = ByteArray(HEAD + 17 + nameB.size + ips.size * 4)
        fill(b, T_HELLO, 0)
        System.arraycopy(myUid, 0, b, HEAD, 16)               // هويتي الثابتة
        b[HEAD + 16] = nameB.size.toByte()
        System.arraycopy(nameB, 0, b, HEAD + 17, nameB.size)  // اسمي
        var o = HEAD + 17 + nameB.size
        for (ip in ips) {
            val a = ip.address
            if (a.size == 4) { System.arraycopy(a, 0, b, o, 4); o += 4 }
        }
        return b
    }

    private fun replyHello(ip: InetAddress) {
        val h = buildHello()
        sendTo(ip, h, h.size)
    }

    private fun parseHello(buf: ByteArray, n: Int, from: InetAddress, pid: Int, ch: Int, now: Long) {
        var o = HEAD
        if (n >= HEAD + 17) {
            val nl = buf[HEAD + 16].toInt() and 0xFF
            if (HEAD + 17 + nl <= n) {
                val uid = hex(buf, HEAD)
                val name = String(buf, HEAD + 17, nl, Charsets.UTF_8)
                if (uid != myUidHex) {
                    val p = users[uid]
                    if (p == null) users[uid] = Peer(uid, name, from, pid, ch, now)
                    else { p.name = name; p.ip = from; p.pid = pid; p.ch = ch; p.last = now }
                }
                o = HEAD + 17 + nl
            }
        }
        readGossip(buf, n, o, now)
    }

    private fun readGossip(buf: ByteArray, n: Int, start: Int, now: Long) {
        var o = start
        while (o + 4 <= n) {
            val a = try {
                InetAddress.getByAddress(byteArrayOf(buf[o], buf[o + 1], buf[o + 2], buf[o + 3]))
            } catch (_: Exception) { null }
            o += 4
            if (a != null && a !in myAddrs && !direct.containsKey(a)) hints[a] = now
        }
    }

    private fun helloLoop(g: Int) {
        var tick = 0
        while (alive(g)) {
            targets = findTargets()
            val now = System.currentTimeMillis()
            peersSeen.entries.removeAll { now - it.value.second > 6000 }
            direct.entries.removeAll { now - it.value > PEER_TTL }
            val b = buildHello()
            send(b, b.size)                                  // بث عام للتعارف
            for (ip in direct.keys) sendTo(ip, b, b.size)    // وأحادي للمعروفين (يبقيهم أحياء حتى لو أُسقط البث)
            for (e in hints.entries) {
                if (now - e.value > 10_000L) hints.remove(e.key) else sendTo(e.key, b, b.size)
            }
            callTick(now)
            if (kickFlag) { kickFlag = false; tick = 0 }   // ظهرت شبكة واي فاي: تعارف سريع من جديد
            tick++
            // أول 10 ثوانٍ: مرحباً كل نصف ثانية لتعارف أسرع، بعدها كل ثانية
            try { Thread.sleep(if (tick < 20) 500L else 1000L) } catch (_: InterruptedException) {}
        }
    }

    private fun receiveLoop(g: Int) {
        val s = sock ?: return
        val buf = ByteArray(2048)
        val pkt = DatagramPacket(buf, buf.size)
        while (alive(g)) {
            try {
                pkt.length = buf.size
                s.receive(pkt)
                val n = pkt.length
                if (n < HEAD || (buf[0].toInt() and 0xFF) != MAGIC) continue
                val bb = ByteBuffer.wrap(buf, 3, 8)
                val id = bb.int
                val sq = bb.int
                if (id == myId) continue
                val ch = buf[1].toInt()
                val type = buf[2].toInt()
                val now = System.currentTimeMillis()
                peersSeen[id] = ch to now
                val from = pkt.address
                if (from != null && from.address.size == 4 && from !in myAddrs) {
                    val isNew = direct.put(from, now) == null
                    hints.remove(from)
                    if (type == T_HELLO) {
                        parseHello(buf, n, from, id, ch, now)
                        if (isNew) replyHello(from)          // ردّ فوري على جهاز جديد بدل انتظار الدورة
                    }
                }
                if (type in T_CALL..T_END) onSignal(type, buf, n, now)
                // أثناء المكالمة نستمع للطرف الآخر فقط؛ وخارجها يعمل اللاسلكي بالقناة كما هو
                val okAudio = if (callState == 3) users[callUid]?.pid == id else ch == channel
                if (type == T_AUDIO && okAudio && listen && (!talking || callState == 3) && n > HEAD) {
                    enqueue(id, buf, n, sq, now)
                }
            } catch (_: SocketTimeoutException) {
            } catch (_: Exception) {
                if (!alive(g)) break
                try { Thread.sleep(20) } catch (_: InterruptedException) {}
            }
        }
    }

    private fun enqueue(id: Int, buf: ByteArray, n: Int, sq: Int, now: Long) {
        val samples = (n - HEAD) / 2
        if (samples <= 0) return
        val all = ShortArray(samples)
        ByteBuffer.wrap(buf, HEAD, samples * 2).order(ByteOrder.LITTLE_ENDIAN).asShortBuffer().get(all)
        val s = srcs.getOrPut(id) { Src() }
        synchronized(s) {
            if (samples == FRAME * 2) {
                // حزمة فيها الإطار السابق + الحالي: إن ضاع السابق نسترجعه، وإن وصل يُسقط كمكرر
                push(s, all.copyOfRange(0, FRAME), sq - 1, now)
                push(s, all.copyOfRange(FRAME, FRAME * 2), sq, now)
            } else push(s, all, sq, now)
        }
        lastRx = now
    }

    /** يُستدعى داخل synchronized(s). */
    private fun push(s: Src, f: ShortArray, sq: Int, now: Long) {
        if (s.started) {
            val d = sq - s.lastSeq
            if (d <= 0 && d > -200) return      // حزمة مكررة أو متأخرة
        }
        if (s.emptyAt != 0L) {
            // امتلأ بعد أن فرغ أثناء الكلام (أقل من 300ms) = تقطّع حقيقي، فكبّر المخزن
            if (now - s.emptyAt < 300 && s.pre < PRE_MAX) s.pre++
            s.emptyAt = 0L
        }
        s.started = true
        s.lastSeq = sq
        s.q.addLast(f)
        while (s.q.size > MAXQ) s.q.pollFirst()
        s.last = now
    }

    // ---------- التشغيل: دمج المتحدثين + رفع القوة ----------

    private fun pause(ns: Long) {
        try { Thread.sleep(ns / 1_000_000L, (ns % 1_000_000L).toInt()) } catch (_: InterruptedException) {}
    }

    private fun playLoop(g: Int) {
        val minBuf = AudioTrack.getMinBufferSize(RATE, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
        fun build(comm: Boolean): AudioTrack? = try {
            AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(if (comm) AudioAttributes.USAGE_VOICE_COMMUNICATION else AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build()
                )
                .setAudioFormat(
                    AudioFormat.Builder().setSampleRate(RATE)
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build()
                )
                .setBufferSizeInBytes(max(minBuf, FRAME * 2 * 4))
                .setTransferMode(AudioTrack.MODE_STREAM)
                .build()
        } catch (_: Exception) { null }
        var comm = callState == 3
        var track: AudioTrack = build(comm) ?: return

        var enh: LoudnessEnhancer? = null
        try { enh = LoudnessEnhancer(track.audioSessionId).also { it.setEnabled(true) } } catch (_: Throwable) {}

        var routedPhone: Boolean? = null
        var level = -1
        val mix = IntArray(FRAME)
        val out = ShortArray(FRAME)
        val lead = ShortArray(FRAME * 2)      // سكون قصير لبناء هامش أمان قبل بدء الكلام
        var wasIdle = true
        var next = System.nanoTime()
        track.play()

        while (alive(g)) {
            val wantComm = callState == 3
            if (wantComm != comm) {
                // دخلنا/خرجنا من مكالمة: نعيد بناء المسار (صوت مكالمة يتيح إلغاء الصدى)
                comm = wantComm
                try { track.stop() } catch (_: Exception) {}
                try { track.release() } catch (_: Exception) {}
                try { enh?.release() } catch (_: Throwable) {}
                enh = null
                track = build(comm) ?: break
                try { enh = LoudnessEnhancer(track.audioSessionId).also { it.setEnabled(true) } } catch (_: Throwable) {}
                routedPhone = null; level = -1; wasIdle = true
                track.play()
            }
            if (routedPhone != phoneAudio) { routedPhone = phoneAudio; route(track, phoneAudio && !comm) }
            if (level != boost) {
                level = boost
                try { enh?.setTargetGain(ENH[level.coerceIn(0, 3)]) } catch (_: Throwable) {}
            }
            mix.fill(0)
            var any = false
            val now = System.currentTimeMillis()
            for (e in srcs.entries) {
                val s = e.value
                if (now - s.last > 3000) { srcs.remove(e.key); continue }
                val f = s.take() ?: continue
                val m = min(f.size, FRAME)
                for (i in 0 until m) mix[i] = mix[i] + f[i].toInt()
                any = true
            }
            if (any) {
                if (wasIdle) { track.write(lead, 0, lead.size); wasIdle = false; next = System.nanoTime() }
                val gn = GAIN[boost.coerceIn(0, 3)]
                for (i in 0 until FRAME) out[i] = (soft(mix[i] * gn / 32768f) * 32767f).toInt().toShort()
                track.write(out, 0, FRAME)
                next += 20_000_000L
                val wait = next - System.nanoTime()
                if (wait > 0) pause(wait) else if (wait < -100_000_000L) next = System.nanoTime()
            } else {
                wasIdle = true
                next = System.nanoTime()
                pause(8_000_000L)
            }
        }
        try { track.stop() } catch (_: Exception) {}
        try { track.release() } catch (_: Exception) {}
        try { enh?.release() } catch (_: Exception) {}
    }

    // ---------- الإرسال: ميكروفون الهاتف ----------

    @SuppressLint("MissingPermission")
    fun talk(on: Boolean) {
        if (!on) { talking = false; return }
        if (!running || talking) return
        startCapture()
    }

    private fun amplifyMic(b: ByteArray, off: Int, len: Int) {
        var i = off
        val end = off + (len and 1.inv())
        while (i < end) {
            val s = (b[i + 1].toInt() shl 8) or (b[i].toInt() and 0xFF)
            val v = (soft(s * MIC_GAIN / 32768f) * 32767f).toInt()
            b[i] = (v and 0xFF).toByte()
            b[i + 1] = (v shr 8).toByte()
            i += 2
        }
    }

    @SuppressLint("MissingPermission")
    private fun captureLoop(g: Int, id: Int) {
        var rec: AudioRecord? = null
        val fx = mutableListOf<AudioEffect>()
        try {
            val minBuf = AudioRecord.getMinBufferSize(RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
            if (minBuf <= 0) throw IllegalStateException("AudioRecord buffer is unavailable")
            val r = AudioRecord(
                if (callState == 3) MediaRecorder.AudioSource.VOICE_COMMUNICATION else MediaRecorder.AudioSource.MIC,
                RATE, AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT, max(minBuf, FRAME * 2 * 8)
            )
            rec = r
            if (r.state != AudioRecord.STATE_INITIALIZED) throw IllegalStateException("Microphone is unavailable")
            if (phoneAudio) try {
                val mic = audio.getDevices(AudioManager.GET_DEVICES_INPUTS)
                    .firstOrNull { it.type == AudioDeviceInfo.TYPE_BUILTIN_MIC }
                if (mic != null) r.setPreferredDevice(mic)
            } catch (_: Exception) {}
            try {
                if (AutomaticGainControl.isAvailable())
                    AutomaticGainControl.create(r.audioSessionId)?.let { it.setEnabled(true); fx.add(it) }
                if (NoiseSuppressor.isAvailable())
                    NoiseSuppressor.create(r.audioSessionId)?.let { it.setEnabled(true); fx.add(it) }
                if (callState == 3 && AcousticEchoCanceler.isAvailable())
                    AcousticEchoCanceler.create(r.audioSessionId)?.let { it.setEnabled(true); fx.add(it) }
            } catch (_: Throwable) {}

            r.startRecording()
            val cur = ByteArray(FRAME * 2)
            val out = ByteArray(HEAD + FRAME * 4)
            var prev: ByteArray? = null
            while (talking && alive(g) && id == capGen) {
                val n = r.read(cur, 0, cur.size)
                if (n < 0) break
                if (n == 0) continue
                val len = n and 1.inv()
                amplifyMic(cur, 0, len)
                fill(out, T_AUDIO, seq++)
                var o = HEAD
                // إطار احتياطي: نرفق الإطار السابق مع الحالي ليُسترجع إن ضاعت الحزمة السابقة
                val p = prev
                if (p != null && len == FRAME * 2 && liveDirect() <= MAX_RED_PEERS) {
                    System.arraycopy(p, 0, out, o, FRAME * 2)
                    o += FRAME * 2
                }
                System.arraycopy(cur, 0, out, o, len)
                o += len
                sendAudio(out, o)
                prev = if (len == FRAME * 2) cur.copyOf() else null
            }
        } catch (_: Exception) {
        } finally {
            if (id == capGen) talking = false
            try { rec?.stop() } catch (_: Exception) {}
            try { rec?.release() } catch (_: Exception) {}
            fx.forEach { try { it.release() } catch (_: Exception) {} }
        }
    }
}
