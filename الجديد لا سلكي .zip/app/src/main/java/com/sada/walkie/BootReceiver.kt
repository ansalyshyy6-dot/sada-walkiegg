package com.sada.walkie

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** بعد إقلاع الهاتف: يُعيد تشغيل الاستقبال إن كان المستخدم قد شغّله من قبل (أفضل جهد؛ أندرويد 14+ قد يمنعه). */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        if (i.action != Intent.ACTION_BOOT_COMPLETED && i.action != "android.intent.action.QUICKBOOT_POWERON") return
        try {
            val p = c.getSharedPreferences("sada_net", Context.MODE_PRIVATE)
            if (p.getString("uid", null) == null) return          // لم يُستخدم التطبيق بعد
            if (!p.getBoolean("boot", true) || !p.getBoolean("wantOn", false)) return
            c.startForegroundService(Intent(c, WalkieService::class.java).setAction(ACT_BOOT))
        } catch (_: Throwable) {}
    }
}
