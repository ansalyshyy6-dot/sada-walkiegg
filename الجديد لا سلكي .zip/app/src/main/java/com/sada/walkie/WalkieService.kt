package com.sada.walkie

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.net.wifi.WifiManager
import android.os.Build
import android.os.IBinder
import android.os.PowerManager

/** خدمة أمامية: تُبقي الجهاز اللاسلكي يعمل عند قفل الشاشة أو الخروج من التطبيق. */
class WalkieService : Service() {
    companion object {
        const val CHANNEL = "sada_radio"
        const val NOTIF_ID = 7
        const val ACTION_STOP = "com.sada.walkie.STOP"
    }

    private var wake: PowerManager.WakeLock? = null
    private var wifi: WifiManager.WifiLock? = null
    private var wifi2: WifiManager.WifiLock? = null
    private var netCb: ConnectivityManager.NetworkCallback? = null
    @Volatile private var fgOk = true

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (nm.getNotificationChannel(CHANNEL) == null) {
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL, "اتصال صدى اللا سلكي", NotificationManager.IMPORTANCE_LOW)
            )
        }
        val flags = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        val open = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP), flags
        )
        val stop = PendingIntent.getService(
            this, 1, Intent(this, WalkieService::class.java).setAction(ACTION_STOP), flags
        )
        val b = Notification.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("صدى اللا سلكي")
            .setContentText("الجهاز اللاسلكي يعمل — اضغط للفتح")
            .setContentIntent(open)
            .setOngoing(true)
            .setCategory(Notification.CATEGORY_SERVICE)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "إيقاف", stop)
        if (Build.VERSION.SDK_INT >= 31) b.setForegroundServiceBehavior(Notification.FOREGROUND_SERVICE_IMMEDIATE)

        try {
            if (Build.VERSION.SDK_INT >= 29) {
                startForeground(NOTIF_ID, b.build(), ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
            } else {
                startForeground(NOTIF_ID, b.build())
            }
        } catch (_: Exception) {
            fgOk = false
            stopSelf(); return
        }

        try {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            wake = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "sada:radio").apply {
                setReferenceCounted(false); acquire(12 * 60 * 60 * 1000L)
            }
            val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            val mode = if (Build.VERSION.SDK_INT >= 29) WifiManager.WIFI_MODE_FULL_LOW_LATENCY
            else WifiManager.WIFI_MODE_FULL_HIGH_PERF
            wifi = wm.createWifiLock(mode, "sada:wifi").apply { setReferenceCounted(false); acquire() }
            // قفل ثانٍ يُبقي الواي فاي نشطاً والشاشة مطفأة (LOW_LATENCY يعمل والشاشة مضاءة فقط)
            @Suppress("DEPRECATION")
            wifi2 = wm.createWifiLock(WifiManager.WIFI_MODE_FULL_HIGH_PERF, "sada:wifi2")
                .apply { setReferenceCounted(false); acquire() }
        } catch (_: Exception) {}

        // عند اتصال الهاتف بأي شبكة واي فاي (عادية أو غيرها) نبدأ التعارف فوراً ليرنّ عليه من يتصل به
        try {
            val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            val cb = object : ConnectivityManager.NetworkCallback() {
                override fun onAvailable(network: Network) { Radio.get(this@WalkieService).kick() }
            }
            cm.registerNetworkCallback(
                NetworkRequest.Builder().addTransportType(NetworkCapabilities.TRANSPORT_WIFI).build(), cb
            )
            netCb = cb
        } catch (_: Exception) {}
    }

    override fun onStartCommand(i: Intent?, flags: Int, startId: Int): Int {
        if (!fgOk) return START_NOT_STICKY
        val r = Radio.get(this)
        when (i?.action) {
            ACT_BOOT -> { if (r.myUidHex.isEmpty()) r.loadIdentity(); r.start() }
            ACTION_STOP -> { r.stop(); stopSelf(); return START_NOT_STICKY }
            ACT_ANSWER -> { if (r.myUidHex.isEmpty()) r.loadIdentity(); r.answer() }
            ACT_DECLINE -> r.decline()
            ACT_HANGUP -> r.hangup()
            null -> { if (r.myUidHex.isEmpty()) r.loadIdentity(); r.start() }   // أعاد النظام تشغيل الخدمة
        }
        return START_STICKY
    }

    override fun onDestroy() {
        try { wake?.release() } catch (_: Exception) {}
        try { wifi?.release() } catch (_: Exception) {}
        try { wifi2?.release() } catch (_: Exception) {}
        netCb?.let { try { (getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager).unregisterNetworkCallback(it) } catch (_: Exception) {} }
        super.onDestroy()
    }
}
